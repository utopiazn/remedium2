package net.madvirus.spring4.chap07.event;

public enum EventType {

	FLASHMOB, CIRCUS, CONFERENCE
}
