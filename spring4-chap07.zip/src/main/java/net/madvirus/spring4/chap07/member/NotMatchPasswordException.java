package net.madvirus.spring4.chap07.member;

@SuppressWarnings("serial")
public class NotMatchPasswordException extends RuntimeException {

}
